export interface Tipo_Remocao {
    tipo_remocao_id?: number,
    nome: string
}